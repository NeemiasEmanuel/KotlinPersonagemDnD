package com.example.personagemdnd

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.personagemdnd.ui.theme.PersonagemDNDTheme
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PersonagemDNDTheme {
                val navController = rememberNavController()
                NavGraph(navController)
            }
        }
    }
}

@Composable
fun NavGraph(navController: NavHostController) {
    val character = remember { Character() }
    var selectedRace by remember { mutableStateOf<Race?>(null) }
    var bonusesApplied by remember { mutableStateOf(false) } // Controle para aplicar bônus uma vez

    NavHost(navController = navController, startDestination = "home_screen") {
        composable("home_screen") {
            HomeScreen(navController)
        }
        composable("race_selection") {
            RaceSelectionScreen(navController) { race ->
                selectedRace = race
                navController.navigate("attribute_assignment")
            }
        }
        composable("attribute_assignment") {
            AttributeAssignmentScreen(navController, character, selectedRace) {
                // Aplica os bônus raciais antes de navegar para o sumário, se ainda não foram aplicados
                if (!bonusesApplied && selectedRace != null) {
                    selectedRace?.applyRacialBonus(character)
                    bonusesApplied = true
                }
                navController.navigate("summary_screen")
            }
        }
        composable("summary_screen") {
            SummaryScreen(character, selectedRace)
        }
     //   composable("character_list") {
       //     CharacterListScreen() // Esta será a tela que criaremos depois para listar personagens
       // }
    }
}
// Nova tela inicial
@Composable
fun HomeScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Bem-vindo ao Criador de Personagens", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = { navController.navigate("race_selection") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        ) {
            Text("Criação de Personagem")
        }

        Button(
            onClick = { navController.navigate("character_list") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        ) {
            Text("Lista de Personagem")
        }
    }
}
// Primeira tela: Seleção de Raça
@Composable
fun RaceSelectionScreen(navController: NavHostController, onRaceSelected: (Race) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Selecione sua Raça", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(20.dp))

        val races = listOf(
            "Humano" to Human(),
            "Anão da Montanha" to MountainDwarf(),
            "Elfo" to Elf(),
            "Meio-Orc" to HalfOrc(),
            "Tiefling" to Tiefling(),
            "Draconato" to Draconato(),
            "Anão da Colina" to HillDwarf(),
            "Halfling Robusto" to StoutHalfling(),
            "Halfling Pés-Leves" to LightfootHalfling(),
            "Gnomo da Floresta" to ForestGnome(),
            "Gnomo das Rochas" to RockGnome(),
            "Alto Elfo" to HighElf(),
            "Elfo da Floresta" to WoodElf(),
            "Meio-Elfo" to HalfElf(),
            "Drow" to Drow()
        )

        // LazyColumn para permitir rolagem
        LazyColumn(
            modifier = Modifier.fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(races) { (raceName, raceInstance) ->
                Button(
                    onClick = {
                        onRaceSelected(raceInstance)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Text(raceName)
                }
            }
        }
    }
}

// Segunda tela: Atribuição de Atributos
@Composable
fun AttributeAssignmentScreen(navController: NavHostController, character: Character, selectedRace: Race?, onFinished: () -> Unit) {
    val pointBuySystem = PointBuySystem()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Distribua seus Pontos de Atributo", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(20.dp))

        Text("Pontos Restantes: ${pointBuySystem.getRemainingPoints(character)}")

        Spacer(modifier = Modifier.height(20.dp))

        // Inputs dos atributos base
        AttributeInput("Força", character.strengthBase) { newValue ->
            if (pointBuySystem.canAssignPoints(character, "strength", newValue)) {
                character.strengthBase = newValue
            }
        }
        AttributeInput("Destreza", character.dexterityBase) { newValue ->
            if (pointBuySystem.canAssignPoints(character, "dexterity", newValue)) {
                character.dexterityBase = newValue
            }
        }
        AttributeInput("Constituição", character.constitutionBase) { newValue ->
            if (pointBuySystem.canAssignPoints(character, "constitution", newValue)) {
                character.constitutionBase = newValue
            }
        }
        AttributeInput("Inteligência", character.intelligenceBase) { newValue ->
            if (pointBuySystem.canAssignPoints(character, "intelligence", newValue)) {
                character.intelligenceBase = newValue
            }
        }
        AttributeInput("Sabedoria", character.wisdomBase) { newValue ->
            if (pointBuySystem.canAssignPoints(character, "wisdom", newValue)) {
                character.wisdomBase = newValue
            }
        }
        AttributeInput("Carisma", character.charismaBase) { newValue ->
            if (pointBuySystem.canAssignPoints(character, "charisma", newValue)) {
                character.charismaBase = newValue
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Botão para ir para a tela de resumo
        Button(onClick = {
            onFinished() // Aplica os bônus e navega para o sumário
        }) {
            Text("Finalizar e Ver Resumo")
        }
    }
}

// Tela de Sumário
// Tela de Sumário
@Composable
fun SummaryScreen(character: Character, selectedRace: Race?) {
    var characterName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Resumo Final", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(20.dp))

        // Campo de entrada de texto para o nome do personagem
        TextField(
            value = characterName,
            onValueChange = { characterName = it },
            label = { Text("Nome do Personagem") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text("Raça Selecionada: ${selectedRace?.javaClass?.simpleName ?: "Nenhuma"}")

        Spacer(modifier = Modifier.height(10.dp))

        // Mostra os valores finais após a aplicação dos bônus
        Text("Força: ${character.strengthBase} (Modificador: ${character.strengthModifier})")
        Text("Destreza: ${character.dexterityBase} (Modificador: ${character.dexterityModifier})")
        Text("Constituição: ${character.constitutionBase} (Modificador: ${character.constitutionModifier})")
        Text("Inteligência: ${character.intelligenceBase} (Modificador: ${character.intelligenceModifier})")
        Text("Sabedoria: ${character.wisdomBase} (Modificador: ${character.wisdomModifier})")
        Text("Carisma: ${character.charismaBase} (Modificador: ${character.charismaModifier})")
        Text("Pontos de Vida: ${character.hitPoints}")
    }
}

@Composable
fun AttributeInput(label: String, value: Int, onValueChange: (Int) -> Unit) {
    Column {
        Text(text = label)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { if (value > 8) onValueChange(value - 1) }) {
                Text("-")
            }
            Text(text = value.toString(), modifier = Modifier.padding(16.dp))
            Button(onClick = { if (value < 15) onValueChange(value + 1) }) {
                Text("+")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    PersonagemDNDTheme {
        RaceSelectionScreen(rememberNavController()) {}
    }
}
