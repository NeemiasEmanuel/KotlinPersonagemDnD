package com.example.personagemdnd.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.personagemdnd.data.entity.Personagem

@Dao
interface PersonagemDAO {
    @Insert
    suspend fun insert(personagem: Personagem)

    @Query("SELECT * FROM personagens")
    suspend fun getAll(): List<Personagem>
}
