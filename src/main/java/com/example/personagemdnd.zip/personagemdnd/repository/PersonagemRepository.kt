package com.example.personagemdnd.repository

import com.example.personagemdnd.data.dao.PersonagemDAO
import com.example.personagemdnd.data.entity.Personagem

class PersonagemRepository(private val personagemDAO: PersonagemDAO) {

    suspend fun insert(personagem: Personagem) {
        personagemDAO.insert(personagem)
    }

    suspend fun getAll(): List<Personagem> {
        return personagemDAO.getAll()
    }
}
