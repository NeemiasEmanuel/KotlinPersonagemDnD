package com.example.personagemdnd

interface Race {
    fun applyRacialBonus(character: Character)
}
