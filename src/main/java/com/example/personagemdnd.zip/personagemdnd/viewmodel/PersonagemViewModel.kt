package com.example.personagemdnd.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.personagemdnd.data.database.AppDatabase
import com.example.personagemdnd.data.entity.Personagem
import com.example.personagemdnd.repository.PersonagemRepository
import kotlinx.coroutines.launch

class PersonagemViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PersonagemRepository

    init {
        val personagemDAO = AppDatabase.getDatabase(application).personagemDAO()
        repository = PersonagemRepository(personagemDAO)
    }

    fun insert(personagem: Personagem) = viewModelScope.launch {
        repository.insert(personagem)
    }

    suspend fun getAll(): List<Personagem> {
        return repository.getAll()
    }
}
